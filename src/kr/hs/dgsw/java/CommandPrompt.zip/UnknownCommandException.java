package kr.hs.dgsw.java.CommandPrompt;

public class UnknownCommandException extends RuntimeException {

    private static final long serialVersionUID = 1L;

}